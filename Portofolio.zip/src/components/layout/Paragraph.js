import React from "react";

function Paragraph({ children }) {
	return <p>{children}</p>;
}

export default Paragraph;